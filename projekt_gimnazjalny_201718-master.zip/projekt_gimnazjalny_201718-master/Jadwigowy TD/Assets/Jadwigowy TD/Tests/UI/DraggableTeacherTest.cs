﻿using UI;
using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;

namespace Tests.UI {
    public class DraggableTeacherTest {

        // I don't know how to do that :P
        // TODO: get know
    }
}
