﻿public struct SettingsData {
    //isFullscreen is saved as byte
    public byte isFullscreen;
    public float masterVolume;
}